# Automation of doctors prescription's image 2 > 2023-05-15 1:55pm
https://universe.roboflow.com/daffodil-international-university-s5vpr/automation-of-doctors-prescription-s-image-2

Provided by a Roboflow user
License: CC BY 4.0

