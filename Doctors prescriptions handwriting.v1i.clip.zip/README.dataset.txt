# Doctors prescriptions handwriting > 2023-06-24 1:12pm
https://universe.roboflow.com/daffodil-international-university-s5vpr/doctors-prescriptions-handwriting

Provided by a Roboflow user
License: CC BY 4.0

